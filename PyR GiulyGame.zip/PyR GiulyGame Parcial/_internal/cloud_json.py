import json, requests

# --- CONFIGURACIÓN ---
JSONBIN_API_KEY = "$2a$10$K3pkS15pUpPLBwQXePqqROpD10g/WaruEOU1/Pc28RkY8b2.hHPyi"
BIN_ID = "6900bed5ae596e708f32f53a"

HEADERS = {
    "Content-Type": "application/json",
    "X-Master-Key": JSONBIN_API_KEY
}

def cargar():
    """Lee los datos JSON desde JSONBin"""
    url = f"https://api.jsonbin.io/v3/b/{BIN_ID}/latest"
    try:
        resp = requests.get(url, headers=HEADERS)
        resp.raise_for_status()
        contenido = resp.json()
        return contenido["record"]  # JSONBin guarda el contenido dentro de "record"
    except Exception as e:
        print("")
        return {}

def guardar(data: dict):
    """Guarda los datos JSON en JSONBin"""
    url = f"https://api.jsonbin.io/v3/b/{BIN_ID}"
    try:
        resp = requests.put(url, headers=HEADERS, json=data)
        resp.raise_for_status()
        print("")
    except Exception as e:
        print("")
